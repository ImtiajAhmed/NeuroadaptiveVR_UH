﻿using UnityEngine;
using System;
using System.Linq;
using Assets.LSL4Unity.Scripts.AbstractInlets;

namespace Assets.LSL4Unity.Scripts.Examples
{
    /// <summary>
    /// Just an example implementation for a Inlet recieving float values
    /// </summary>
    public class ExampleFloatInlet : AFloatInlet
    {
        //public string lastSample = String.Empty;
        public float newSample;
        private double lastTimeStamp;


        protected override void Process(float[] sample, double timeStamp)
        {
            // just as an example, make a string out of all channel values of this sample
            //lastSample = string.Join(" ", newSample.Select(c => c.ToString()).ToArray());
            newSample = sample[0];
            //timeForTargetSpeed = (float)(timeStamp - lastTimeStamp) * 0.75f;
            lastTimeStamp = timeStamp;
            SendMessage("UpdateStarSpeed", SendMessageOptions.DontRequireReceiver);
            //Debug.Log(string.Format("Got {0} samples at {1}", sample.Length, timeStamp));
           // string st = string.Empty;
           // for(int i=0;i< newSample.Length; i++)
           //     st+= newSample[i].ToString() + " ,";
          //  Debug.Log(st);
        }
    }
}