﻿/*
* Imtiaj Ahmed
* 11.06.2020
* University of Helsinki
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Physiology
{
    public static VALUE delta, theta, alpha, beta, gamma;
}

public struct VALUE
{
    public float min, max, val;
}

