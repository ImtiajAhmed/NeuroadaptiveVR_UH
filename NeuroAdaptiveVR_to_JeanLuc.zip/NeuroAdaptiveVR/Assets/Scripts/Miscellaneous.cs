﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Text;

public class Miscellaneous : MonoBehaviour
{
    public EEGMarker eegMarker_calibration, eegMarker_exp2;
    public Text info, debugInfo, viewData, viewSpeedInfo;
    public RawImage hourglass;

    public IEnumerator ShowInstruction(string fileName)
    {
        info.text = System.IO.File.ReadAllText(fileName);
        while (!Input.GetKeyDown(KeyCode.DownArrow)) yield return 0;
        info.text = "";
        yield return 0;
    }

    public IEnumerator DisplayHourglass()
    {
        hourglass.enabled = true;
        yield return new WaitForSeconds(0.5f); //give a time
        hourglass.enabled = false;
    }

    private void OnDestroy()
    {
        eegMarker_calibration.Disconnect();
        eegMarker_exp2.Disconnect();
    }


    #region SubjectInfo

    public string playerDOB = string.Empty, playerGender = string.Empty;  //user's demographic info
    public int subjectID = 0;
    public int exp2_trialID = 0, expOld_trialID = 0;

    //subjectID,exp2LastTrialID,expOldLastTrialID,playerGender,playerDOB

    public IEnumerator UpdateSubjectInfo()
    {
        LoadAppStatus();
        bool startFromLastTrial = false;
        if ((exp2_trialID != 0)|| (expOld_trialID != 0))
        {
            info.text = "Some trials are remain undone for the last participant. <br>Would you continue as the last participant? <Y or N>";
            while (!Input.GetKeyDown(KeyCode.Y) && !Input.GetKeyDown(KeyCode.N)) yield return null;
            if (Input.GetKeyDown(KeyCode.Y))
            {
                startFromLastTrial = true;
            }
            else
            {
                exp2_trialID = 0;
                expOld_trialID = 0;
                playerGender = "";
                playerDOB = "";                
            }
            info.text = string.Empty;
        }

        if(!startFromLastTrial)
        {
            subjectID++;  //otherwise, get a new participant information
            bool userIdOk = false;
            while (!userIdOk)
            {
                info.text = "USER ID: " + subjectID.ToString() + System.Environment.NewLine + "change using -,+ keys, Enter to select";
                if (Input.GetKeyDown(KeyCode.KeypadMinus) || Input.GetKeyDown(KeyCode.Minus))
                {
                    subjectID--;
                }
                else if (Input.GetKeyDown(KeyCode.KeypadPlus) || Input.GetKeyDown(KeyCode.Plus))
                {
                    subjectID++;
                }
                else if (Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetKeyDown(KeyCode.Return))
                {
                    userIdOk = true;
                }
                yield return null;
            }
            info.text = string.Empty;

            bool userAgeOk = false;
            while (!userAgeOk)
            {
                info.text = "Player DoB or Age: " + playerDOB.ToString() + System.Environment.NewLine + "press Enter when you are done";

                if (Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetKeyDown(KeyCode.Return))
                {
                    userAgeOk = true;
                }
                else if (Input.GetKeyDown(KeyCode.Backspace))
                {
                    if (playerDOB.Length > 0)
                        playerDOB = playerDOB.Remove(playerDOB.Length - 1);
                }
                else playerDOB += Input.inputString;
                yield return null;
            }


            bool playerGenderOk = false;
            while (!playerGenderOk)
            {
                info.text = "Player Gender: <M>Male  <F>Female ";

                if (Input.GetKeyDown(KeyCode.M))
                {
                    playerGender = "male";
                    playerGenderOk = true;
                }
                else if (Input.GetKeyDown(KeyCode.F))
                {
                    playerGender = "female";
                    playerGenderOk = true;
                }

                yield return null;
            }

            info.text = string.Empty;
        }  
        yield return null;
    }

    void LoadAppStatus() //resolve the trial id, if some reason system crash then next time app will run from the last unfinished trial
    {
        //first load the value from the AppStatus.txt file
        try
        {
            string line = null;
            StreamReader theReader = new StreamReader("ConfigFiles/AppStatus.txt", Encoding.Default);
            using (theReader)
            {
                line = theReader.ReadLine();
                if (line != null)
                {
                    string[] entries = line.Split(',');
                    int.TryParse(entries[0], out subjectID);     //subjectID,exp2LastTrialID,expOldLastTrialID,playerGender,playerDOB
                    int.TryParse(entries[1], out exp2_trialID);
                    int.TryParse(entries[2], out expOld_trialID);
                    playerGender = entries[3].Trim();
                    playerDOB = entries[4].Trim();
                }
                theReader.Close();
            }
        }
        catch (System.IO.IOException e)
        {
            info.text = e.Message;
            Debug.Log("LoadAppStatus " + e.Message);
        }     
    }

    #endregion

}


//shuffle a list
public static class IListExtensions
{ //from smooth.foundations
  /// <summary>
  /// Shuffles the element order of the specified list.
  /// </summary>
    public static void Shuffle<T>(this IList<T> ts)
    {
        var count = ts.Count;
        var last = count - 1;
        for (var i = 0; i < last; ++i)
        {
            var r = UnityEngine.Random.Range(i, count);
            var tmp = ts[i];
            ts[i] = ts[r];
            ts[r] = tmp;
        }
    }

}