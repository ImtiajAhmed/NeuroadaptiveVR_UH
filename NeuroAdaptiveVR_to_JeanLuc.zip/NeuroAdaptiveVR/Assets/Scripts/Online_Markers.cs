﻿using UnityEngine;
using System.Collections;
using System.IO;
using System.Text;

public class Online_Markers
{
    int walk_neuroadaptive, walk_recorded, walk_blank, run_neuroadaptive, run_recorded, run_blank, run_detected, walk_detected, unclear_detected, end_task;
    

    public void LoadOnlineMarkers(string fileName)
    {
        try
        {
            string line = null;
            StreamReader theReader = new StreamReader(fileName, Encoding.Default);
            using (theReader)
            {
                do
                {
                    line = theReader.ReadLine();
                    if (line != null)
                    {
                        //line = line.ToLower ().Trim();
                        string[] entries = line.Split('=');

                        if (entries[0].Contains("walk_neuro"))
                            int.TryParse(entries[1], out walk_neuroadaptive);
                        if (entries[0].Contains("walk_recorded"))
                            int.TryParse(entries[1], out walk_recorded);
                        if (entries[0].Contains("walk_blank"))
                            int.TryParse(entries[1], out walk_blank);
                        if (entries[0].Contains("run_neuro"))
                            int.TryParse(entries[1], out run_neuroadaptive);
                        if (entries[0].Contains("run_recorded"))
                            int.TryParse(entries[1], out run_recorded);
                        if (entries[0].Contains("run_blank"))
                            int.TryParse(entries[1], out run_blank);

                        if (entries[0].Contains("run_detected"))
                            int.TryParse(entries[1], out run_detected);
                        if (entries[0].Contains("walk_detected"))
                            int.TryParse(entries[1], out walk_detected);
                        if (entries[0].Contains("unclear_detected"))
                            int.TryParse(entries[1], out unclear_detected);
                        if (entries[0].Contains("endTask"))
                            int.TryParse(entries[1], out end_task);

                    }
                } while (line != null);

                theReader.Close();
            }
        }
        catch (System.IO.IOException e)
        {
            UnityEngine.Debug.Log(e.Message);
        }

    }

    public int GetMarker(string markername)
    {
        if (markername == "walk_neuroadaptive")
            return walk_neuroadaptive;
        else if (markername == "walk_recorded") 
            return walk_recorded;
        else if (markername == "walk_blank")
            return walk_blank;
        else if (markername == "run_neuroadaptive")
            return run_neuroadaptive;
        else if (markername == "run_recorded")
            return run_recorded;
        else if (markername == "run_blank")
            return run_blank;
        else if (markername == "run_detected")
            return run_detected;
        else if (markername == "walk_detected")
            return walk_detected;
        else if (markername == "unclear_detected")
            return unclear_detected;
        else if (markername == "end_task")
            return end_task;
        else return 0;
    }
       
}
