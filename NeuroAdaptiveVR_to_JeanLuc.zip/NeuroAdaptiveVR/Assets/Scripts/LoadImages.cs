﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class LoadImages : MonoBehaviour
{
    //public string imageName = "Run.png";
    //public RawImage rawImage;

    // Start is called before the first frame update
    // Use this for initialization
    IEnumerator Start()
    {
        // read image and store in a byte array
		byte[] byteArray = File.ReadAllBytes("ConfigFiles/Images/"+this.gameObject.name+".png");
        //create a texture and load byte array to it
        // Texture size does not matter 
        Texture2D sampleTexture = new Texture2D(2, 2);
        // the size of the texture will be replaced by image size
        bool isLoaded = sampleTexture.LoadImage(byteArray);
        // apply this texure as per requirement on image or material
        //GameObject image = GameObject.Find("RawImage");
       
        if (isLoaded)
        {
			this.gameObject.GetComponent<RawImage>().texture = sampleTexture;
        }
        yield return 0;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

/*
        Debug.Log("dataPath : " + Application.dataPath);
        WWW www = new WWW("file:///" +Application.dataPath + "ConfigFiles/Images/"+imageName);
        while (!www.isDone)
            yield return null;
        if (www.isDone)
            Debug.Log("is done");
       // GameObject image = GameObject.Find("RawImage");
        rawImage.GetComponent<RawImage>().texture = www.texture;
 */
