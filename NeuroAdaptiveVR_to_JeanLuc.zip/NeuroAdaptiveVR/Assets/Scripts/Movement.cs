﻿/*
 * Imtiaj Ahmed
 * 11.02.2020
 * University of Helsinki
 * 
 */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.LSL4Unity.Scripts;
using Assets.LSL4Unity.Scripts.Examples;
using UnityEngine.UI;

public class Movement : MonoBehaviour
{
    public ParticleSystem ps;
    public Text speedText;

    private ExampleFloatInlet inlet;

    float playbackSpeed = 0.1f, targetSpeed = 1f;
    float timeForTargetSpeed = 0.7f, time4target;
    //ParticleSystem.MainModule main;

    // Start is called before the first frame update
    void Start()
    {
        inlet = FindObjectOfType<ExampleFloatInlet>();
        speedText.text = "Speed: " + playbackSpeed.ToString();
    }
    
    void EnableSpeedText(bool enb)
    {
        speedText.enabled = enb;
    }

    void UpdateStarSpeed(float speed)
    {
        //targetSpeed = (Mathf.Lerp(0.2f, 2f, speed)); //  /100
        var main = ps.main;
        main.simulationSpeed = speed;// (Mathf.Lerp(0.2f, 2.5f, playbackSpeed));
        speedText.text = "Speed: " + speed.ToString();
    }

    float deltaSpeed = 0f;
    // Update is called once per frame
    void Update()
    {
        /*
        if (time4target > 0)
        {
            deltaSpeed = (targetSpeed - playbackSpeed) / time4target;
            playbackSpeed += deltaSpeed;
            time4target -= Time.deltaTime;
            var main = ps.main;
            main.simulationSpeed = (Mathf.Lerp(0.5f, 2f, playbackSpeed));
            speedText.text = "Speed: " + playbackSpeed.ToString();
        }
        */
    }
}
