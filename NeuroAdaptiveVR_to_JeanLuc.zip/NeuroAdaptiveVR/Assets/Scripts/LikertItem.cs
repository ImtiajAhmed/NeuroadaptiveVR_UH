﻿/*
 * Imtiaj Ahmed
 * Dept. of Computer Science
 * University of Helsinki
 * December, 2020
 * 
 * This script handles likert item
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Text;
using System.IO;

public class LikertItem : MonoBehaviour
{
    public Text leftTxt, rightTxt, ques, value;
    public Slider slider;

    bool interactSlider = false;

    public Text info, debugInfo;


    public class EXP2_LIKERT_ITEM //leftText, rightText, question, minValue, maxValue, isWholeNumber, isRandDefaltValue
    {
        public string leftText, rightText, question;
        public float minValue, maxValue;
        public bool isWholeNumber, isRandDefaltValue, shouldShowValue;
    }

    List<EXP2_LIKERT_ITEM> exp2_trial_end_likert_items = new List<EXP2_LIKERT_ITEM>();
    List<EXP2_LIKERT_ITEM> exp2_block_end_likert_items = new List<EXP2_LIKERT_ITEM>();

    public string exp2_likert_item_questions = string.Empty, exp2_likert_item_answers = string.Empty;

    // Start is called before the first frame update
    void Start()
    {
        DeactivateSlider();
    }

    // Update is called once per frame
    void Update()
    {
       
    }

    public void SetSliderParameters(EXP2_LIKERT_ITEM tmpItem)
    {
        leftTxt.text = tmpItem.leftText;
        rightTxt.text = tmpItem.rightText;
        ques.text = tmpItem.question;
        slider.minValue = tmpItem.minValue;
        slider.maxValue = tmpItem.maxValue;
        if (tmpItem.isRandDefaltValue)
            slider.value = Random.Range((tmpItem.maxValue - tmpItem.minValue) / 4f, (tmpItem.maxValue - tmpItem.minValue) * 3f / 4f);
        else slider.value = tmpItem.minValue;
		value.text = slider.value.ToString();
        if (tmpItem.shouldShowValue)
            value.enabled = true;
        else value.enabled = false;

        slider.wholeNumbers = tmpItem.isWholeNumber;
    }

    void DeactivateSlider()
    {
        leftTxt.text = rightTxt.text = ques.text = value.text = string.Empty;
        interactSlider = false;
        slider.gameObject.SetActive(false);
    }

    public IEnumerator Exp2_AskQuestions_Trial_End()
    {
        
        exp2_likert_item_answers = string.Empty;
        debugInfo.text = "question";
        yield return AskQuestions(exp2_trial_end_likert_items);
        
        yield return 0;
    }

    public IEnumerator Exp2_AskQuestions_Block_End()
    {
        yield return AskQuestions(exp2_block_end_likert_items);
        yield return 0;
    }

    void UpdateSliderValue(float val)
    {
        slider.value += val;
        value.text = slider.value.ToString();
    }

    public IEnumerator AskQuestions(List<EXP2_LIKERT_ITEM> exp2_likert_items)
    {
        slider.gameObject.SetActive(true);
         
        int qIndex = 0;
        while (qIndex < exp2_likert_items.Count)
        {
            Debug.Log("qIndex " + qIndex.ToString() + " items " + exp2_likert_items[qIndex].question); ;

            debugInfo.text = "question " + qIndex.ToString();
            SetSliderParameters(exp2_likert_items[qIndex]);

            //now interact with the slider
            while (!Input.GetKeyDown(KeyCode.DownArrow)) //press down arrow to submit an answer
            {
                if (!slider.wholeNumbers)
                    UpdateSliderValue(Input.GetAxis("Horizontal") * AppSet.sliderSpeed);
                else
                {
                    if (Input.GetKeyDown(KeyCode.LeftArrow))
                    {
                        UpdateSliderValue(-1);
                        float tmpLeftArrowTime = 0f;
                        float tmpSensitivityDuration = AppSet.sliderFastMoveSensitivityInSeconds;

                        while (!Input.GetKeyUp(KeyCode.LeftArrow))
                        {
                            tmpLeftArrowTime += Time.deltaTime;

                            if(tmpLeftArrowTime>AppSet.sliderFastMoveActivatingThresholdTime)
                            {
                                tmpSensitivityDuration += Time.deltaTime;
                                if (tmpSensitivityDuration > AppSet.sliderFastMoveSensitivityInSeconds)
                                {
                                    tmpSensitivityDuration = 0f;
                                    UpdateSliderValue(-1);
                                }                                
                            }
                                
                            yield return 0;
                        }
                    }
                        
                    else if (Input.GetKeyDown(KeyCode.RightArrow))
                    {
                        UpdateSliderValue(1);
                        float tmpRightArrowTime = 0f;
                        float tmpSensitivityDuration = AppSet.sliderFastMoveSensitivityInSeconds;

                        while (!Input.GetKeyUp(KeyCode.RightArrow))
                        {
                            tmpRightArrowTime += Time.deltaTime;

                            if (tmpRightArrowTime > AppSet.sliderFastMoveActivatingThresholdTime)
                            {
                                tmpSensitivityDuration += Time.deltaTime;
                                if (tmpSensitivityDuration > AppSet.sliderFastMoveSensitivityInSeconds)
                                {
                                    tmpSensitivityDuration = 0f;
                                    UpdateSliderValue(1);
                                }
                            }
                               
                            yield return 0;
                        }
                    }                        
                }
                 yield return 0; //break for the next frame
            }
            
            exp2_likert_item_answers += AppSet.Sep + slider.value.ToString(); //set answer as a string
            qIndex++; //for next question
            yield return 0; //break for the next frame
        }

        //all answers ready, simply return
        DeactivateSlider();
        yield return 0;
    }

    public void Exp2_LoadLikertItems()  ///leftText, rightText, question, minValue, maxValue, isWholeNumber, isRandDefaltValue
    {
        //first load trial end questionnaire
        LoadLikertItems("ConfigFiles/Exp2_Trial_End_Questionnaire.txt", exp2_trial_end_likert_items);

        //now load block end questionnaire
        LoadLikertItems("ConfigFiles/Exp2_Block_End_Questionnaire.txt", exp2_block_end_likert_items);
    }

    void LoadLikertItems(string filename, List<EXP2_LIKERT_ITEM> exp2_likert_items)  ///leftText, rightText, question, minValue, maxValue, isWholeNumber, isRandDefaltValue
    {
        if (System.IO.File.Exists(filename))
        {
            try
            {
                string line = null;
                StreamReader theReader = new StreamReader(filename, Encoding.Default);

                line = theReader.ReadLine();// skip the first line which contains heading

                using (theReader)
                {
                    do
                    {

                        line = theReader.ReadLine();

                        if (line != null)
                        {
                            string[] entries = line.Split(AppSet.Sep.ToCharArray());
                            EXP2_LIKERT_ITEM tmpTrial = new EXP2_LIKERT_ITEM();

                            tmpTrial.leftText = entries[0].Trim();
                            tmpTrial.rightText = entries[1].Trim();
                            tmpTrial.question = entries[2].Trim();
                            exp2_likert_item_questions += AppSet.Sep + tmpTrial.question;
                        Debug.Log("loading questions"+ exp2_likert_item_questions);
                            float.TryParse(entries[3], out tmpTrial.minValue);
                            float.TryParse(entries[4], out tmpTrial.maxValue);

                            bool.TryParse(entries[5], out tmpTrial.isWholeNumber);
                            bool.TryParse(entries[6], out tmpTrial.isRandDefaltValue);
                            bool.TryParse(entries[7], out tmpTrial.shouldShowValue);
                            
                            exp2_likert_items.Add(tmpTrial);
                        }
                    } while (line != null);

                    theReader.Close();
                    //theReader2.Close ();
                }
            }
            catch (System.IO.IOException e)
            {
                info.text = e.Message;
                Debug.Log("LoadTrials " + e.Message);
            }
        }
        else
        {
            info.text = filename+" Not found";
            Debug.Log(filename + " Not found");
        }
    }

    void OnDestroy()
    {
        exp2_trial_end_likert_items.Clear();
        exp2_block_end_likert_items.Clear();
    }
}
