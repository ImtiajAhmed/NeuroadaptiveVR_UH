﻿using UnityEngine;
using System.Collections;
using System.IO;
using System.Text;
using TMPro;

public class AppSet{
	public static string Sep = ",";

    public static float calibration_task_duration = 8f;
    public static float calibration_task_interval = 4f;
    public static int calibration_task_repetition = 10;
    public static float calibration_clipart_duration = 0.5f;
    public static bool calibration_change_speed_on_task = false;
    public static bool calibration_show_task_info = false;
    public static float calibration_show_task_info_duration = 0.5f;

    public static float star_speed_max = 20f, star_speed_min = 0.1f;
    public static int star_speed_au_level = 9;
    public static int default_au_speed_level_index = -1;
    public static int exponential_moving_avg_filter_size = 3;
    public static float exponential_moving_avg_filter_alpha = 0.6f;

    public static bool show_walk_run_icon = true;
    public static bool show_stop_icon = true;
    public static bool play_start_stop_audio = true;
    public static bool show_hour_glass = true;

    public static float class_run_threshold = 0.3f, class_walk_threshold = 0.7f;
    public static int number_of_classifiers_to_use_in_vote = 4;

    public static float sliderSpeed = 0.01f;
    public static float sliderFastMoveActivatingThresholdTime = 1f;
    public static float sliderFastMoveSensitivityInSeconds = 0.1f;



    public static string take_a_break_statement  = "Break Time. Press down arrow when you are done!";
	public static string trial_file_type = ".txt";
	public static string log_file_type = ".txt";
	public static string nl= System.Environment.NewLine;
    
    public static string exp2_OverInfo = "Experiment 2 ended";
    public static string oldExp_OverInfo = "Old Experiment ended";

    public static string trainingSession = "Training Session";
    public static string experimentSession = "Experiment Session";

    public static string eeg_marker_ip = "192.168.0.2"; //"localhost"
    public static int eeg_marker_port = 15361;




    public static void LoadAppSettings(string fileName)
	{		
		try 
		{
			string line = null;
			StreamReader theReader = new StreamReader (fileName, Encoding.Default);
			using (theReader) 
			{
				do 
				{
					line = theReader.ReadLine ();
					if (line != null) 
					{
						//line = line.ToLower ().Trim();
						string[] entries = line.Split('=');

						if(entries[0].Contains("separator"))
							Sep = entries[1].Trim();

                        if (entries[0].Contains("calibration_task_duration"))
                            float.TryParse(entries[1], out calibration_task_duration);
                        if (entries[0].Contains("calibration_task_interval"))
                            float.TryParse(entries[1], out calibration_task_interval);
                        if (entries[0].Contains("calibration_task_repetition"))
                            int.TryParse(entries[1], out calibration_task_repetition);
                        if (entries[0].Contains("calibration_clipart_duration"))
                            float.TryParse(entries[1], out calibration_clipart_duration);
                        if (entries[0].Contains("calibration_change_speed_on_task"))
                            bool.TryParse(entries[1], out calibration_change_speed_on_task);
                        if (entries[0].Contains("calibration_show_task_info"))
                            bool.TryParse(entries[1], out calibration_show_task_info);                        
                        if (entries[0].Contains("calibration_show_task_info_duration"))
                            float.TryParse(entries[1], out calibration_show_task_info_duration);
                        


                        if (entries[0].Contains("star_speed_max"))
                            float.TryParse(entries[1], out star_speed_max);
                        if (entries[0].Contains("star_speed_min"))
                            float.TryParse(entries[1], out star_speed_min);
                        if (entries[0].Contains("star_speed_au_level"))
                            int.TryParse(entries[1], out star_speed_au_level);
                        if (entries[0].Contains("default_au_speed_level_index"))
                            int.TryParse(entries[1], out default_au_speed_level_index);

                        if (entries[0].Contains("exponential_moving_avg_filter_size"))
                            int.TryParse(entries[1], out exponential_moving_avg_filter_size);
                        if (entries[0].Contains("exponential_moving_avg_filter_alpha"))
                            float.TryParse(entries[1], out exponential_moving_avg_filter_alpha);

                        if (entries[0].Contains("show_walk_run_icon"))
                            bool.TryParse(entries[1], out show_walk_run_icon);
                        if (entries[0].Contains("show_stop_icon"))
                            bool.TryParse(entries[1], out show_stop_icon);
                        
                        if (entries[0].Contains("play_start_stop_audio"))
                            bool.TryParse(entries[1], out play_start_stop_audio);
                        if (entries[0].Contains("show_hour_glass"))
                            bool.TryParse(entries[1], out show_hour_glass);
                        

                        if (entries[0].Contains("class_run_threshold"))
                            float.TryParse(entries[1], out class_run_threshold);
                        if (entries[0].Contains("class_walk_threshold"))
                            float.TryParse(entries[1], out class_walk_threshold);
                        if (entries[0].Contains("number_of_classifiers_to_use_in_vote"))
                            int.TryParse(entries[1], out number_of_classifiers_to_use_in_vote);

                       
                        if (entries[0].Contains("sliderSpeed"))
                            float.TryParse(entries[1], out sliderSpeed);
                        if (entries[0].Contains("sliderFastMoveActivatingThresholdTime"))
                            float.TryParse(entries[1], out sliderFastMoveActivatingThresholdTime);
                        if (entries[0].Contains("sliderFastMoveSensitivityInSeconds"))
                            float.TryParse(entries[1], out sliderFastMoveSensitivityInSeconds);
                        


                        if (entries[0].Contains("take_a_break_statement"))
							take_a_break_statement = entries[1].Trim();
						if(entries[0].Contains("trial_file_type"))
							trial_file_type = entries[1].Trim();
						if(entries[0].Contains("log_file_type"))
							log_file_type = entries[1].Trim();
						 
						if (entries[0].Contains("exp2_OverInfo"))
                            exp2_OverInfo = entries[1].Trim();
                        if (entries[0].Contains("oldExp_OverInfo"))
                            oldExp_OverInfo = entries[1].Trim();
                        if (entries[0].Contains("trainingSession"))
                            trainingSession = entries[1].Trim();
                        if (entries[0].Contains("experimentSession"))
                            experimentSession = entries[1].Trim();

                        if (entries[0].Contains("eeg_marker_ip"))
                            eeg_marker_ip = entries[1].Trim();
                        if (entries[0].Contains("eeg_marker_port"))
                            int.TryParse(entries[1], out eeg_marker_port);
}
				} while(line != null);

				theReader.Close ();
			}
		} 
		catch (System.IO.IOException e) 
		{
			UnityEngine.Debug.Log(e.Message);
		}

	}
		
}
