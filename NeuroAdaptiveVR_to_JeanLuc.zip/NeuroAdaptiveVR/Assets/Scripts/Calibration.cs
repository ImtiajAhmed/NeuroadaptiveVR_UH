﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Calibration : Miscellaneous
{
    public GameObject runClipArt, walkClipArt, stopClipArt;
   
    // Start is called before the first frame update
    void Start()
    {
     
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnDestroy()
    {
        tasks.Clear();
    }

    public struct TASK
    {
        public string item;
        public byte marker;
    }

    public List<TASK> tasks = new List<TASK>();

    public void GenerateCalibrationTasks()
    {
        //create a list of all single tasks
        List<TASK> allSingletasks = new List<TASK>();
        TASK task1 = new TASK();
        task1.item = "walk";
        task1.marker = (byte)11;
        allSingletasks.Add(task1);
        TASK task2 = new TASK();
        task2.item = "run";
        task2.marker = (byte)21;
        allSingletasks.Add(task2);


        //create temporary tasks list

        for (int i = 0; i < AppSet.calibration_task_repetition; i++)
            for (int j = 0; j < allSingletasks.Count; j++)
            {
                TASK tmpTask = new TASK();
                tmpTask.item = allSingletasks[j].item;
                tmpTask.marker = allSingletasks[j].marker;
                tasks.Add(tmpTask);
            }
        //now shuffle the list
        tasks.Shuffle();
    }


    protected GameObject clipart_walk_run;

    public IEnumerator ShowWalkRunClipArt(string walkRun)
    {
        if (walkRun.Contains("walk"))
        {
            walkClipArt.SetActive(true);
            yield return new WaitForSeconds(AppSet.calibration_clipart_duration);
            walkClipArt.SetActive(false);
        }
        else
        {
            runClipArt.SetActive(true);
            yield return new WaitForSeconds(AppSet.calibration_clipart_duration);
            runClipArt.SetActive(false);
        }
    }

    public IEnumerator ShowStopClipArt()
    {
        stopClipArt.SetActive(true);
        yield return new WaitForSeconds(AppSet.calibration_clipart_duration);
        stopClipArt.SetActive(false);
      
    }


    public IEnumerator Calibrate()
    {
        starSystemRenderer.enabled = false;
        yield return ShowInstruction("ConfigFiles/NeuroCalibration_Instruction.txt");
        starSystemRenderer.enabled = true;

        yield return new WaitForSeconds(2f); //wait a while to prepare for the task

        //Run the tasks/trials


        for (int i = 0; i < tasks.Count; i++)
        {
            //info.text = tasks[i].item;
            //display clipart
            if (tasks[i].item.Contains("walk"))
                clipart_walk_run = walkClipArt;
            else clipart_walk_run = runClipArt;

            if(AppSet.calibration_show_task_info) //if task (run/walk) text need to show before the emoticon, so that participant has time to prepare
            {
                info.text = "Get ready to "+tasks[i].item;
                yield return new WaitForSeconds(AppSet.calibration_show_task_info_duration);
                info.text = string.Empty;
            }

            clipart_walk_run.SetActive(true);

            if (AppSet.calibration_change_speed_on_task)
            {
                if (tasks[i].item.Contains("walk"))
                    SendMessage("UpdateStarSpeed", (AppSet.star_speed_max-AppSet.star_speed_min)/4f, SendMessageOptions.DontRequireReceiver);  //walk
                else SendMessage("UpdateStarSpeed", (AppSet.star_speed_max - AppSet.star_speed_min) * 3f / 4f, SendMessageOptions.DontRequireReceiver); //run
            }

            eegMarker_calibration.SendTrigger(tasks[i].marker); //send marker of the task to the raw data 
            yield return new WaitForSeconds(AppSet.calibration_clipart_duration);
            clipart_walk_run.SetActive(false);
            yield return new WaitForSeconds(AppSet.calibration_task_duration - AppSet.calibration_clipart_duration);
            
            stopClipArt.SetActive(true);

            //info.text = "Stop";
            eegMarker_calibration.SendTrigger((byte)10);
            if (AppSet.calibration_change_speed_on_task)
                SendMessage("UpdateStarSpeed", (AppSet.star_speed_max - AppSet.star_speed_min) / 2f, SendMessageOptions.DontRequireReceiver); //run
            yield return new WaitForSeconds(AppSet.calibration_clipart_duration);
            stopClipArt.SetActive(false);
            yield return new WaitForSeconds(AppSet.calibration_task_interval - AppSet.calibration_clipart_duration); //wait for a while             
        }

        //send start training trigger to the training scenario
        eegMarker_calibration.SendTrigger((byte)25);
     
        info.text = "Calibration task ended.";
        debugInfo.text = "Calibration task ended...";
    }


    #region StarMovement
    public ParticleSystem starSystem;
    public ParticleSystemRenderer starSystemRenderer;

    public void UpdateStarSpeed(float starSpeed, int indx,  float maxSpeed)
    {
        var main = starSystem.main;
        main.simulationSpeed = starSpeed;// (Mathf.Lerp(0.2f, 2.5f, playbackSpeed));
        viewSpeedInfo.text = "Speed Level: " + indx.ToString() + AppSet.nl + "Speed : " + starSpeed.ToString() + AppSet.nl + "Max Speed : "+ maxSpeed.ToString();
    }
    #endregion 
}
