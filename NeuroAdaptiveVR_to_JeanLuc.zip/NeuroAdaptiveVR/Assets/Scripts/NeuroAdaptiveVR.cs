﻿/*
/* Imtiaj Ahmed
* 11.06.2020
* 17.09.2020
* 18.09.2020
* University of Helsinki
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.IO;
using System.Text;

public class NeuroAdaptiveVR : Calibration
{
    bool user_take_a_break = false, waitForSomething = false, is_exp2_running = false, is_oldExp_running = false, isOpenvibeProcessCalled = false;

    private AcquireOpenVibeData inlet;
    private LikertItem likertScript;

    Online_Markers online_markers = new Online_Markers();

    AudioSource voice;
    public AudioClip start_voice_clip, stop_voice_clip;

    #region Start_Update_Destroy
    // Start is called before the first frame update
    void Start()
    {
        voice = GetComponent<AudioSource>();
        online_markers.LoadOnlineMarkers("ConfigFiles/Online_Markers.txt");        
       
        inlet = FindObjectOfType<AcquireOpenVibeData>();
        likertScript = FindObjectOfType<LikertItem>();
        
        AppSet.LoadAppSettings("ConfigFiles/AppSet.txt");

        eegMarker_calibration = new EEGMarker();
        eegMarker_exp2 = new EEGMarker();

        /*
                eegMarker = new EEGMarker();
                //eegMarker.Connect("localhost", 15361);
                //eegMarker.Connect("192.168.0.2", 15361);
                eegMarker.Connect(AppSet.eeg_marker_ip, AppSet.eeg_marker_port);
           */
        SendMessage("Initialize", SendMessageOptions.DontRequireReceiver);      
        
    }

    
    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.C))
            UnityEngine.XR.InputTracking.Recenter();
        if (Input.GetKeyDown(KeyCode.B))
            user_take_a_break = true;
       

        if (Input.GetKeyDown(KeyCode.KeypadDivide))
            UpdateStarSpeed(exp2_au_speeds[AppSet.star_speed_au_level-1], AppSet.star_speed_au_level, exp2_au_speeds[AppSet.star_speed_au_level - 1]);
        if (Input.GetKeyDown(KeyCode.KeypadMultiply))
            UpdateStarSpeed(exp2_au_speeds[0], 1, exp2_au_speeds[AppSet.star_speed_au_level - 1]);

        if (Input.GetKeyDown(KeyCode.L))
        {
            SendMessage("Exp2_AskQuestions_Trial_End", SendMessageOptions.DontRequireReceiver);
        }

        if (Input.GetKeyDown(KeyCode.H))
        {
            starSystemRenderer.enabled = !starSystemRenderer.enabled;
        }
    }

    void OnDestroy()
    {
        exp2_data.Clear();
        exp2_recordedClassesFor_10s_walk.Clear();
        exp2_recordedClassesFor_20s_walk.Clear();
        exp2_recordedClassesFor_30s_walk.Clear();
        exp2_recordedClassesFor_10s_run .Clear();
        exp2_recordedClassesFor_20s_run .Clear();
        exp2_recordedClassesFor_30s_run .Clear();
        exp2_trials.Clear();
    }




    #endregion

    IEnumerator Initialize()
    {
		SetExponentialSpeed();
        //set speed parameters

        //run the stars faster so that user fit in the middle of the starfield
        UpdateStarSpeed(exp2_au_speeds[exp2_au_speeds.Length - 1], exp2_au_speeds.Length, exp2_au_speeds[exp2_au_speeds.Length - 1]);
        starSystemRenderer.enabled = false;
        yield return new WaitForSeconds(0.9f); 
        //now we can slow down the speed and show to the user
        UpdateStarSpeed(exp2_au_speeds[0], 1, exp2_au_speeds[exp2_au_speeds.Length - 1]);
        yield return new WaitForSeconds(0.1f);
        starSystemRenderer.enabled = true;

       
        GenerateCalibrationTasks();

        yield return new WaitForSeconds(1f);
        likertScript.Exp2_LoadLikertItems();

        exp2_rawClassesForVoting = new char[AppSet.number_of_classifiers_to_use_in_vote];

        yield return UpdateSubjectInfo();

        yield return 0;
    }

   


    #region OnButtonClick

    public void OnCalibrationButtonClick()
    {
        debugInfo.text = "";
        if(!eegMarker_calibration.isConnected())
            eegMarker_calibration.Connect(AppSet.eeg_marker_ip, AppSet.eeg_marker_port);

        if (!eegMarker_calibration.isConnected())
            debugInfo.text = "Please run the Openvibe acqusition server and designer scenario first and then click Calibration button again";
        else      
            SendMessage("Calibrate", false, SendMessageOptions.DontRequireReceiver);
    }

    public void OnExperiment2ButtonClick()
    {
        debugInfo.text = "";
       // if(eegMarker!=null)
     //       eegMarker.Disconnect();
        if (!eegMarker_exp2.isConnected())
            eegMarker_exp2.Connect(AppSet.eeg_marker_ip, AppSet.eeg_marker_port);
            

        if (!eegMarker_exp2.isConnected())
            debugInfo.text = "Please run the Openvibe acqusition server and designer scenario first and then click Experiment2 button again";
        else
            SendMessage("Experiment2", false, SendMessageOptions.DontRequireReceiver);
    }

    public void OnOldExperimentButtonClick()
    {
        SendMessage("OldExperiment", false, SendMessageOptions.DontRequireReceiver);
    }

    public void OnReCenterButtonClick()
    {
        UnityEngine.XR.InputTracking.Recenter();
    }

    public void OnTakeAbreakButtonClick()
    {
        user_take_a_break = true;
    }

    public void OnExitButtonClick()
    {
        Application.Quit();
    }

	public void OnViewSpeedDataButtonClick()
	{
		viewData.enabled = !viewData.enabled;
	}

    bool isOnlineSpeedTest = false;
    public void OnOnlineSpeedTestButtonClick()
	{
        //speed test while eeg is active 
        starSystemRenderer.enabled = true;

        Exp2_ResetRawClassesAndSpeedLevel(); //reset Classes array and speed value
        UpdateStarSpeed(exp2_au_speeds[exp2_median_au_speed_level_index], exp2_median_au_speed_level_index + 1, exp2_au_speeds[exp2_au_speeds.Length-1]); //set the speed in the middle
        isOnlineSpeedTest = true;
    }


    public void OnOnlineSpeedTestDoneButtonClick()
    {
        //speed test while eeg is active 
        isOnlineSpeedTest = false;
        Exp2_ResetRawClassesAndSpeedLevel(); //reset Classes array and speed value
        UpdateStarSpeed(exp2_au_speeds[exp2_median_au_speed_level_index], exp2_median_au_speed_level_index + 1, exp2_au_speeds[exp2_au_speeds.Length - 1]); //set the speed in the middle
        viewData.text = "Detected : " +AppSet.nl + "Used : " + AppSet.nl + "voting : ";
    }

    public void OnDemoSpeedButtonClick()
	{
        //Show demo speed
        SendMessage("DemoStarSpeed", SendMessageOptions.DontRequireReceiver);

    }

    IEnumerator DemoStarSpeed()
    {
        for (int i = 0; i < AppSet.star_speed_au_level; i++)
        {
            exp2_au_speed_level_index = i;
            UpdateStarSpeed(exp2_au_speeds[i], i+1, exp2_au_speeds[exp2_au_speeds.Length - 1]); //set the speed in the middle
            yield return new WaitForSeconds(2f); //give a time
        }                
        yield return 0;
    }

    public void OnSlowerButtonClick()
    {
        exp2_au_speed_level_index--;
        if (exp2_au_speed_level_index < 0) exp2_au_speed_level_index = 0;
        UpdateStarSpeed(exp2_au_speeds[exp2_au_speed_level_index], exp2_au_speed_level_index+1, exp2_au_speeds[exp2_au_speeds.Length - 1]); 
    }
    public void OnFasterButtonClick()
    {
        exp2_au_speed_level_index++;
        if (exp2_au_speed_level_index > (AppSet.star_speed_au_level-1)) exp2_au_speed_level_index = AppSet.star_speed_au_level - 1;
        UpdateStarSpeed(exp2_au_speeds[exp2_au_speed_level_index], exp2_au_speed_level_index+1, exp2_au_speeds[exp2_au_speeds.Length - 1]);
    }

    #endregion




    #region Process_Openvibe_data

    //Calls from AcquireOpenVibeData script
    void ProcessOpenvibeData()
    {
        if (exp2_shouldCollectData)
            exp2_ProcessAndCollectOpenvibeData();
        else if (isOnlineSpeedTest)
        {
            //Debug.Log("ProcessOpenvibeData 2");
            OnlineSpeedTest_PrcoessOpenvibeData();
        }
        //Debug.Log("ProcessOpenvibeData");
        isOpenvibeProcessCalled = true; //used for synchronizing time of Exp2
    }
    #endregion

    #region Experiment2
    int exp2_au_speed_level_index = 4, exp2_median_au_speed_level_index = 4; //counted from 0..8 = 9 levels, 4 is median
    float[] exp2_au_speeds; //stores the speed data
    string exp2_logFileName; 
    string exp2_trialHeader = string.Empty;

    string exp2_eventName; //use this to update event name. 
    char[] exp2_rawClassesForVoting;

    bool is_Exp2_trialDuration_timerStarts = false;

    public struct EXP2_DATA  //"timestamp" + SEP + "classifier_value" + SEP + "detected_class" + SEP + "used_class" + SEP + "winner_class" + SEP + "voting_classes" + SEP + "au_speed_level";
    {
        public double timeStamp;
        public float classifier_value;
        public string detected_class, used_class, winner_class, voting_classes;
        public int au_speed_level;
    }

    List<EXP2_DATA> exp2_data = new List<EXP2_DATA>();

    bool exp2_shouldCollectData = false, exp2_shouldUpdateStarSpeed = false;

    List<char> exp2_recordedClassesFor_10s_walk = new List<char>();
    List<char> exp2_recordedClassesFor_20s_walk = new List<char>();
    List<char> exp2_recordedClassesFor_30s_walk = new List<char>();
    List<char> exp2_recordedClassesFor_10s_run = new List<char>();
    List<char> exp2_recordedClassesFor_20s_run = new List<char>();
    List<char> exp2_recordedClassesFor_30s_run = new List<char>();

    List<char> exp2_recordedClasses_pointer = new List<char>(); //used to update the right list
    int exp2_recordedClasses_pointer_index = 0; //used as index to get the value from the exp2_recordedClassesFor_


    void Exp2_ClearEquivalentRecordedClasses() //cals only when feedback type is neuroadaptive
    {
        if(exp2_trials[exp2_trialID].task.Contains("walk")) //walk
        {
            if (exp2_trials[exp2_trialID].task_duration == 10)
                exp2_recordedClassesFor_10s_walk.Clear();
            else if(exp2_trials[exp2_trialID].task_duration == 20)
                exp2_recordedClassesFor_20s_walk.Clear();
            else exp2_recordedClassesFor_30s_walk.Clear();
        }
        else //run
        {
            if (exp2_trials[exp2_trialID].task_duration == 10)
                exp2_recordedClassesFor_10s_run.Clear();
            else if (exp2_trials[exp2_trialID].task_duration == 20)
                exp2_recordedClassesFor_20s_run.Clear();
            else exp2_recordedClassesFor_30s_run.Clear();
        }
    }

    void Exp2_SetRecordedClasses_pointer() //calls only when feedback type is neuroadaptive or recorded
    {
        if (exp2_trials[exp2_trialID].task.Contains("walk")) //walk
        {
            if (exp2_trials[exp2_trialID].task_duration == 10)
                exp2_recordedClasses_pointer = exp2_recordedClassesFor_10s_walk;
            else if (exp2_trials[exp2_trialID].task_duration == 20)
                exp2_recordedClasses_pointer = exp2_recordedClassesFor_20s_walk;
            else exp2_recordedClasses_pointer = exp2_recordedClassesFor_30s_walk;
        }
        else //run
        {
            if (exp2_trials[exp2_trialID].task_duration == 10)
                exp2_recordedClasses_pointer = exp2_recordedClassesFor_10s_run;
            else if (exp2_trials[exp2_trialID].task_duration == 20)
                exp2_recordedClasses_pointer = exp2_recordedClassesFor_20s_run;
            else exp2_recordedClasses_pointer = exp2_recordedClassesFor_30s_run;
        }
        exp2_recordedClasses_pointer_index = 0; //used for recorded feedback, to get data from the beginning  
    }

    void OnlineSpeedTest_PrcoessOpenvibeData()
    {
        Debug.Log("OnlineSpeedTest_PrcoessOpenvibeData");
        char detected_class = '?', used_class = '?', winner_class = '?';

        if (inlet.probability > AppSet.class_walk_threshold)
            detected_class = 'w';
        else if (inlet.probability < AppSet.class_run_threshold)
            detected_class = 'r';
            
        else
            detected_class = '?';
            
        used_class = detected_class; //use used_class as same as detected_class when feedback type is neuroadaptive or blank

              //set raw Classes
        for (int i = 1; i < AppSet.number_of_classifiers_to_use_in_vote; i++)
            exp2_rawClassesForVoting[i - 1] = exp2_rawClassesForVoting[i];
        exp2_rawClassesForVoting[AppSet.number_of_classifiers_to_use_in_vote - 1] = used_class;

        winner_class = Exp2_WinnerClass(); //find winner class
        Exp2_Set_au_speed_level(winner_class); //set the au speed level

        //now update star speed
        UpdateStarSpeed(exp2_au_speeds[exp2_au_speed_level_index], exp2_au_speed_level_index + 1, exp2_au_speeds[exp2_au_speeds.Length - 1]);

        //for viewing 
        viewData.text = "Detected : " + detected_class + AppSet.nl + "Used : " + used_class + AppSet.nl + "voting : " + new string(exp2_rawClassesForVoting);
    }

    void exp2_ProcessAndCollectOpenvibeData()
    {
        char detected_class = '?', used_class = '?', winner_class ='?';

        if (inlet.probability > AppSet.class_walk_threshold)
        {
            detected_class = 'w';
            //send marker to the eeg data
            eegMarker_exp2.SendTrigger((byte)online_markers.GetMarker("walk_detected"));
        }           
        else if (inlet.probability < AppSet.class_run_threshold)
        {
            detected_class = 'r';
            //send marker to the eeg data
            eegMarker_exp2.SendTrigger((byte)online_markers.GetMarker("run_detected"));
        }
        else
        {
            detected_class = '?';
            //send marker to the eeg data
            eegMarker_exp2.SendTrigger((byte)online_markers.GetMarker("unclear_detected"));
        }

        used_class = detected_class; //use used_class as same as detected_class when feedback type is neuroadaptive or blank

        if (exp2_trials[exp2_trialID].feedback.Contains("recorded")) // feedback type is recorded, hence need to use class value from the recorded dataset
        {
            if (exp2_recordedClasses_pointer_index < exp2_recordedClasses_pointer.Count)
            {
                used_class = exp2_recordedClasses_pointer[exp2_recordedClasses_pointer_index];
                exp2_recordedClasses_pointer_index++;
            }
            else used_class = 'x'; //if it misses data. And the winner class will be -> ?
        }        
        else if (exp2_trials[exp2_trialID].feedback.Contains("neuro"))
        {
            exp2_recordedClasses_pointer.Add(used_class); //add the current state to the list
        }

        //set true when it detects walk/run. Exp2_NextTrial() uses it only once for the first time 
        if (exp2_trials[exp2_trialID].task.Contains(used_class.ToString()))
            is_Exp2_trialDuration_timerStarts = true;

        //set raw Classes
        for (int i = 1; i < AppSet.number_of_classifiers_to_use_in_vote; i++)
            exp2_rawClassesForVoting[i-1] = exp2_rawClassesForVoting[i];
        exp2_rawClassesForVoting[AppSet.number_of_classifiers_to_use_in_vote - 1] = used_class;

        winner_class = Exp2_WinnerClass(); //find winner class
        Exp2_Set_au_speed_level(winner_class); //set the au speed level

        //now update star speed
        UpdateStarSpeed(exp2_au_speeds[exp2_au_speed_level_index], exp2_au_speed_level_index+1, exp2_au_speeds[exp2_au_speeds.Length-1]);

       
        //"timestamp" + SEP + "classifier_value" + SEP + "detected_class" + SEP + "used_class" + SEP + "winner_class" + SEP + "voting_classes" + SEP + "au_speed_level";
        EXP2_DATA tmp_exp2_data = new EXP2_DATA();
        tmp_exp2_data.timeStamp = inlet.timeStamp;
        tmp_exp2_data.classifier_value = inlet.probability;
        tmp_exp2_data.detected_class = exp2_rawClassesForVoting[AppSet.number_of_classifiers_to_use_in_vote - 1].ToString();
        tmp_exp2_data.used_class = used_class.ToString();
        tmp_exp2_data.winner_class = winner_class.ToString();
        tmp_exp2_data.voting_classes = new string(exp2_rawClassesForVoting);
        tmp_exp2_data.au_speed_level = exp2_au_speed_level_index + 1;

        exp2_data.Add(tmp_exp2_data);

        //for viewing 
        viewData.text = "Detected : " + tmp_exp2_data.detected_class + AppSet.nl + "Used : " + tmp_exp2_data.used_class + AppSet.nl + "voting : " + tmp_exp2_data.voting_classes;
    }

    char Exp2_WinnerClass()
    {
        int runCount = 0, walkCount = 0, unclearCount = 0;

        for(int i=0;i< AppSet.number_of_classifiers_to_use_in_vote;i++)
        {
            if (exp2_rawClassesForVoting[i] == 'r')
                runCount++;
            else if (exp2_rawClassesForVoting[i] == 'w')
                walkCount++;
            else unclearCount++;
        }

        char winner = '?';
        if (runCount > walkCount)
        {
            if (runCount > unclearCount)
                winner = 'r';
        }
        else if(runCount < walkCount) winner = 'w';

        return winner;
    }

    void Exp2_Set_au_speed_level(char winner)
    {
        if (winner == 'r')
        {
            if (exp2_au_speed_level_index < AppSet.star_speed_au_level - 1) exp2_au_speed_level_index++;
        }
        else if (winner == 'w')
        {
            if (exp2_au_speed_level_index > 0) exp2_au_speed_level_index--;
        }
        else //unclear, force to set in the middle 
        {
            if (exp2_au_speed_level_index > exp2_median_au_speed_level_index) exp2_au_speed_level_index--;
            else if (exp2_au_speed_level_index < exp2_median_au_speed_level_index) exp2_au_speed_level_index++;
        }
    }

    void Exp2_ResetRawClassesAndSpeedLevel()
    {
        for (int i = 0; i < AppSet.number_of_classifiers_to_use_in_vote; i++)
            exp2_rawClassesForVoting[i] = '?';
        exp2_au_speed_level_index = exp2_median_au_speed_level_index;
    }

    void SetExponentialSpeed()
    {
        exp2_au_speeds = new float[AppSet.star_speed_au_level];

        UpdateExponentialSpeed(AppSet.star_speed_min,AppSet.star_speed_max);            
    }

    /*
    void UpdateExponentialSpeed(float maxSpeed)
    {
        if (AppSet.default_au_speed_level_index > -1)
            exp2_median_au_speed_level_index = AppSet.default_au_speed_level_index;
        else exp2_median_au_speed_level_index = (int)AppSet.star_speed_au_level / 2; //initially in the middle

        //y=b^x+c; y=b^x produces y=1 at x=0, and at x=1 we want nearly 0.1, hence need to subtract c=1.1, therefore y=b^x-c 
        //at x = AppSet.star_speed_au_level, we want y = AppSet.star_speed_max, hence need to calculate appropriate b
        float c = 1.1f;
        float b = Mathf.Pow(10f, Mathf.Log10(maxSpeed + c) / AppSet.star_speed_au_level); //log inverse (y) = base ^ y, here base is 10
        //now y=b^x-c 
        for (int x = 0; x < AppSet.star_speed_au_level; x++)
        {
            exp2_au_speeds[x] = Mathf.Pow(b, x + 1) - c;
            Debug.Log("Exponential " + (x + 1).ToString() + " : " + exp2_au_speeds[x].ToString());
        }
    }
*/
    void UpdateExponentialSpeed(float minSpeed, float maxSpeed)
    {
        if (AppSet.default_au_speed_level_index > -1)
            exp2_median_au_speed_level_index = AppSet.default_au_speed_level_index;
        else exp2_median_au_speed_level_index = (int)AppSet.star_speed_au_level / 2; //initially in the middle

        float[] tmpSpeeds = new float[AppSet.star_speed_au_level];
        //10^(1+(xstep/nsteps)), so min will be 10, max will be 100
        for (int i = 0; i < AppSet.star_speed_au_level; i++)
        {
            float log10base = Mathf.Pow(10f, (1 + i / (AppSet.star_speed_au_level - 1f)));
            Debug.Log("log10 = "+ log10base);
            //now scale it down to 0-1
            float scale_0to1 = (log10base - 10f) / 90f;
            exp2_au_speeds[i] = minSpeed + (scale_0to1 * (maxSpeed - minSpeed));
            Debug.Log("Exponential " + (i + 1).ToString() + " : " + exp2_au_speeds[i].ToString());
        }
    }

    void Exp2_Initialize()
    {
        exp2_logFileName = "SubjectData/TrialsLog/" + subjectID.ToString() + "_Exp2" + AppSet.log_file_type;        

		//SetExponentialSpeed(); //its now called from the Initialize() 
        Load_RecordedClasses();
        Exp2_ResetRawClassesAndSpeedLevel();//will also called from the Expreiment2 in the beginning of each trial
    }
  
    IEnumerator Experiment2()  
    {
        starSystemRenderer.enabled = false; //hide stars
        //is_exp2_running = true;
        Exp2_Initialize(); //initialize
        
        LoadExp2Trials("Trials_Exp2");

        if(exp2_trialID > 0)  //check if some trials remain undone before system breaks.
        {
            info.text = "Would you like to continue from the last trial? <Y or N>";
            while (!Input.GetKeyDown(KeyCode.Y) && !Input.GetKeyDown(KeyCode.N)) yield return null;
            if (Input.GetKeyDown(KeyCode.N))
            {
                exp2_trialID = 0; //will repeat from the beginning
            }
           //else run from the current index <since array index starts from 0>
            info.text = string.Empty;
        }

       //show instruction
        //yield return ShowInstruction("ConfigFiles/Exp2_Instruction.txt");

        yield return new WaitForSeconds(1f); //give a seconds to get ready for the trials

        // run the experiment 
        exp2_current_block_id = 0;
        SendMessage("Exp2_NextTrial", SendMessageOptions.DontRequireReceiver);//call for the next trial

        yield return 0;
    }

    void PlayStartStopAudio(AudioClip startstop)
    {
        voice.clip = startstop;
        voice.Play();
    }

    int exp2_current_block_id = 0;

    IEnumerator Exp2_NextTrial()
    {
        if (exp2_trialID < exp2_trials.Count)
        {
            if(exp2_trials[exp2_trialID].block_id != exp2_current_block_id)
            {
                exp2_current_block_id = exp2_trials[exp2_trialID].block_id;
                yield return ShowInstruction("ConfigFiles/Exp2_Block_"+ exp2_trials[exp2_trialID].block_id.ToString()+ "_Instruction.txt");
                yield return new WaitForSeconds(0.5f); //give a time
            }

            UpdateExponentialSpeed(exp2_trials[exp2_trialID].minStarSpeed, exp2_trials[exp2_trialID].maxStarSpeed);//set exponential star speed for the current trial

            Exp2_ResetRawClassesAndSpeedLevel(); //reset Classes array and speed value
            UpdateStarSpeed(exp2_au_speeds[exp2_median_au_speed_level_index], exp2_median_au_speed_level_index+1, exp2_au_speeds[exp2_au_speeds.Length - 1]); //set the speed in the default

            if (exp2_trials[exp2_trialID].feedback.Contains("neuroadaptive")) 
            {
               // starSystemRenderer.enabled = true;  //show stars, if neuroadaptive
                Exp2_ClearEquivalentRecordedClasses();
                Exp2_SetRecordedClasses_pointer();
            }
            else if(exp2_trials[exp2_trialID].feedback.Contains("recorded"))
            {
               // starSystemRenderer.enabled = true;  //show stars, if recorded
                Exp2_SetRecordedClasses_pointer();
            }

            isOpenvibeProcessCalled = false; //used for synchronizing time of Exp2
            while (!isOpenvibeProcessCalled)
                yield return 0; //wait until ProcessOpenvibeData set it true. Then we have a fixed interval to start trial
            
           
            //send marker to the eeg data, task is started
            eegMarker_exp2.SendTrigger((byte)online_markers.GetMarker(exp2_trials[exp2_trialID].task + "_" + exp2_trials[exp2_trialID].feedback));

            if (exp2_trials[exp2_trialID].task.Contains("walk"))
                clipart_walk_run = walkClipArt;
            else
                clipart_walk_run = runClipArt;

            clipart_walk_run.SetActive(true); //show the task icon/image/ walk/run

            //wait until user presses down arrow to start the trial
            while (!Input.GetKeyDown(KeyCode.DownArrow) && !Input.GetKeyDown(KeyCode.Keypad2))  //wait until down arrow key pressed
                yield return 0;

            clipart_walk_run.SetActive(false); //hide the task icon/image/ walk/run

            exp2_shouldCollectData = true; //start collecting and processing data 


            //no nothing for 1s
            yield return new WaitForSeconds(1f);

            //now stars appears for 10/20/30s

            if (exp2_trials[exp2_trialID].feedback.Contains("neuroadaptive"))
                starSystemRenderer.enabled = true;  //show stars, if neuroadaptive                
            else if (exp2_trials[exp2_trialID].feedback.Contains("recorded"))
                starSystemRenderer.enabled = true;  //show stars, if recorded
            
            //now show the flash to give a cue of timing start
            if (AppSet.play_start_stop_audio)
            {
                voice.clip = start_voice_clip;
                voice.Play();
                // SendMessage("PlayStartStopAudio", start_voice_clip, SendMessageOptions.DontRequireReceiver);
            }
            if(AppSet.show_hour_glass)
                SendMessage("DisplayHourglass", SendMessageOptions.DontRequireReceiver); 
            
            //now start the actual delay defined in the trial
            yield return new WaitForSeconds(exp2_trials[exp2_trialID].task_duration);

            //now hide stars
            starSystemRenderer.enabled = false;
                       
            //now stop data collecting
            exp2_shouldCollectData = false;

            //send marker to the eeg data, task is ended
            eegMarker_exp2.SendTrigger((byte)online_markers.GetMarker("end_task"));


            //show the stop emoticon
            if (AppSet.show_stop_icon)
               yield return ShowStopClipArt();

            if (AppSet.play_start_stop_audio)
            {
                voice.clip = stop_voice_clip;
                voice.Play();
                yield return new WaitForSeconds(voice.clip.length);
                // SendMessage("PlayStartStopAudio", start_voice_clip, SendMessageOptions.DontRequireReceiver);
                // yield return new WaitForSeconds(0.5f);
            }


            //no nothing for 1s
            yield return new WaitForSeconds(1f);

            //now ask trial end questions
            yield return likertScript.Exp2_AskQuestions_Trial_End();
            //ask block end questions
            if (exp2_trials[exp2_trialID].ask_end_group_questionnaire)
                yield return likertScript.Exp2_AskQuestions_Block_End();

            //now log the data
            yield return Exp2_LogTrialData();

            //update the status
            UpdateAppStatus(subjectID.ToString() + "," + exp2_trialID.ToString() + "," + expOld_trialID.ToString() + ",,"); //subjectID,exp2LastTrialID,expOldLastTrialID,playerGender,playerDOB
            //Take a break
            if (user_take_a_break)
            {
                info.text = AppSet.take_a_break_statement;

                while (!Input.GetKeyDown(KeyCode.DownArrow) && !Input.GetKeyDown(KeyCode.Keypad2))  //wait until down arrow key pressed
                    yield return 0;
                user_take_a_break = false;
                info.text = "";
            }

            exp2_trialID++;
            SendMessage("Exp2_NextTrial", SendMessageOptions.DontRequireReceiver);//call for the next trial
        }
        else //end of experiment
        {
            info.text = AppSet.exp2_OverInfo;
            exp2_trialID = 0;
            UpdateAppStatus(subjectID.ToString() + "," + exp2_trialID.ToString() + "," + expOld_trialID.ToString() + ",,"); //subjectID,exp2LastTrialID,expOldLastTrialID,playerGender,playerDOB
            Save_RecordedClasses(); //save the recorded states
        }      
        yield return 0;
    }

   
    public class EXP2TRIAL //trial_id,task,task_duration, feedback
    {
        public int block_id, trialID;
        public string task;
        public int task_duration;
        public string feedback;
        public bool ask_end_group_questionnaire;
        public float minStarSpeed, maxStarSpeed;
    }

    List<EXP2TRIAL> exp2_trials = new List<EXP2TRIAL>();
    
    
    void LoadExp2Trials(string fileName)
    {
        string trialFileName = "ConfigFiles/Trials/" + subjectID.ToString() + "_" + fileName + AppSet.trial_file_type;
        //Debug.Log("trial file name : "+ trialFileName);
        if (System.IO.File.Exists(trialFileName))
        {
            try
            {
                string line = null;
                StreamReader theReader = new StreamReader(trialFileName, Encoding.Default);

                line = theReader.ReadLine();// skip the first line which contains heading
                exp2_trialHeader = line.ToLower();

                using (theReader)
                {
                    do
                    {
                        line = theReader.ReadLine();

                        if (line != null)
                        {
                            string[] entries = line.Split(AppSet.Sep.ToCharArray());
                            EXP2TRIAL tmpTrial = new EXP2TRIAL();

                            int.TryParse(entries[0], out tmpTrial.block_id);
                            int.TryParse(entries[1], out tmpTrial.trialID);
                            tmpTrial.task = entries[2].Trim().ToLower();

                            int.TryParse(entries[3], out tmpTrial.task_duration);
                            tmpTrial.feedback = entries[4].Trim().ToLower();
                            bool.TryParse(entries[5], out tmpTrial.ask_end_group_questionnaire);
                            float.TryParse(entries[6], out tmpTrial.minStarSpeed);
                            float.TryParse(entries[7], out tmpTrial.maxStarSpeed);

                            exp2_trials.Add(tmpTrial);
                        }
                    } while (line != null);

                    theReader.Close();
                    //theReader2.Close ();
                }
            }
            catch (System.IO.IOException e)
            {
                info.text = e.Message;
                Debug.Log("LoadTrials " + e.Message);
            }
        }
        else
        {
            info.text = "No Trials file found";
            Debug.Log("No Trials file found");
        }      
    }


    IEnumerator Exp2_LogTrialData()  //trial_id,task,task_duration, feedback
    {
        string SEP = AppSet.Sep;
        //add header
        if (!System.IO.File.Exists(exp2_logFileName))
        {
            string header = "p_id" + SEP + "p_sex" + SEP + "p_dob" + SEP + exp2_trialHeader + SEP + "timestamp" + SEP + "classifier_value" + SEP + "detected_class" + SEP + "used_class" + SEP + "winner_class" + SEP + "voting_classes" + SEP + "au_speed_level"+ SEP+ "all_speed_values"+ likertScript.exp2_likert_item_questions;
            System.IO.File.AppendAllText(exp2_logFileName, header);
        }
                                                                                                                                                                                                                  //block_id,trial_id,task,task_duration,feedback,ask_end_group_questionnaire

        string s = System.Environment.NewLine + subjectID.ToString() + SEP + playerGender + SEP + playerDOB + SEP + exp2_trials[exp2_trialID].block_id.ToString()+ SEP+(exp2_trialID+1).ToString() + SEP + exp2_trials[exp2_trialID].task + SEP + exp2_trials[exp2_trialID].task_duration.ToString() + SEP + exp2_trials[exp2_trialID].feedback + SEP+ exp2_trials[exp2_trialID].ask_end_group_questionnaire.ToString()+ SEP + exp2_trials[exp2_trialID].minStarSpeed.ToString() + SEP + exp2_trials[exp2_trialID].maxStarSpeed.ToString() + SEP;


        string speed_values = exp2_au_speeds[0].ToString();
        for (int x = 1; x < AppSet.star_speed_au_level; x++)
            speed_values += ";"+exp2_au_speeds[x].ToString();

            //now log the openvibe related data
            for (int i = 0; i < exp2_data.Count; i++)
        {
            System.IO.File.AppendAllText(exp2_logFileName, s);
            string db_str = exp2_data[i].timeStamp.ToString() + SEP + exp2_data[i].classifier_value.ToString() + SEP + exp2_data[i].detected_class + SEP + exp2_data[i].used_class + SEP + exp2_data[i].winner_class + SEP + exp2_data[i].voting_classes + SEP + exp2_data[i].au_speed_level + SEP + speed_values + likertScript.exp2_likert_item_answers;
            System.IO.File.AppendAllText(exp2_logFileName, db_str);            
        }
        exp2_data.Clear();
        yield return 0;
    }
    
    void AddCharToRecordedClass(string line, List<char> recordedClasses_pointer)
    {
        string[] entries = line.Split('=');
        char[] states = entries[1].Trim().ToCharArray();
        for (int i = 0; i < states.Length; i++)
        {
            char tmpState = states[i];
            recordedClasses_pointer.Add(tmpState);
            Debug.Log("state char "+ tmpState);
        }
    }

    void Load_RecordedClasses()
    {       
        string recordedClassesFileName = "ConfigFiles/RecordedClasses.txt";
        //Debug.Log("trial file name : "+ trialFileName);
        if (System.IO.File.Exists(recordedClassesFileName))
        {
            try
            {
                string line = null;
                StreamReader theReader = new StreamReader(recordedClassesFileName, Encoding.Default);

                using (theReader)
                {
                    line = theReader.ReadLine();// skip the first line which contains heading
                    AddCharToRecordedClass(line, exp2_recordedClassesFor_10s_walk);

                    line = theReader.ReadLine();// skip the first line which contains heading
                    AddCharToRecordedClass(line, exp2_recordedClassesFor_20s_walk);

                    line = theReader.ReadLine();// skip the first line which contains heading
                    AddCharToRecordedClass(line, exp2_recordedClassesFor_30s_walk);

                    line = theReader.ReadLine();// skip the first line which contains heading
                    AddCharToRecordedClass(line, exp2_recordedClassesFor_10s_run);

                    line = theReader.ReadLine();// skip the first line which contains heading
                    AddCharToRecordedClass(line, exp2_recordedClassesFor_20s_run);

                    line = theReader.ReadLine();// skip the first line which contains heading
                    AddCharToRecordedClass(line, exp2_recordedClassesFor_30s_run);

                    theReader.Close();                    
                }
            }
            catch (System.IO.IOException e)
            {
                info.text = e.Message;
                Debug.Log("LoadTrials " + e.Message);
            }
        }
        else
        {
            info.text = "No RecordedClasses file found";
            Debug.Log("No RecordedClasses file found");
        }
    }

    void Save_RecordedClasses()
    {
        string recordedClassesFileName = "ConfigFiles/RecordedClasses.txt";

        string str = "exp2_recordedClassesFor_10s_walk =" + new string(exp2_recordedClassesFor_10s_walk.ToArray());
        str+= System.Environment.NewLine+ "exp2_recordedClassesFor_20s_walk =" + new string(exp2_recordedClassesFor_20s_walk.ToArray());
        str += System.Environment.NewLine + "exp2_recordedClassesFor_30s_walk =" + new string(exp2_recordedClassesFor_30s_walk.ToArray());

        str += System.Environment.NewLine + "exp2_recordedClassesFor_10s_run =" + new string(exp2_recordedClassesFor_10s_run.ToArray());
        str += System.Environment.NewLine + "exp2_recordedClassesFor_20s_run =" + new string(exp2_recordedClassesFor_20s_run.ToArray());
        str += System.Environment.NewLine + "exp2_recordedClassesFor_30s_run =" + new string(exp2_recordedClassesFor_30s_run.ToArray());

        System.IO.File.WriteAllText(recordedClassesFileName, str);
    }

    #endregion

    void UpdateAppStatus(string status)
    {
        System.IO.File.WriteAllText("ConfigFiles/AppStatus.txt", status);
    }

}


