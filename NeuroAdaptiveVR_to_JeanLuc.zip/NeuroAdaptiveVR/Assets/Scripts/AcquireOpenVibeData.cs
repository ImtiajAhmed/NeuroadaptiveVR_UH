﻿/*
 * Imtiaj Ahmed
 * Sept 2020 
 * University of Helsinki
 * 
 */

 /*
  * This script acquires data from the openVibe
  */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.LSL4Unity.Scripts.AbstractInlets;

public class AcquireOpenVibeData : AFloatInlet
{
    public double timeStamp;
    public float probability;


    protected override void Process(float[] sample, double timestamp)
    {

        probability = sample[0];
        timeStamp = timestamp;
        SendMessage("ProcessOpenvibeData", SendMessageOptions.DontRequireReceiver);

        //Debug.Log("probability = " + probability);
    }
}

