﻿/*
 * Imtiaj Ahmed
 * 11.06.2020
 * University of Helsinki
 * 
 * 
 * This script communicates and sends marker to the openvibe acquisition server
 * The marker is of 24bytes. [uint64 flags ; uint64 stimulation_identifier ; uint64 timestamp] see more at http://openvibe.inria.fr/tcp-tagging/
 * 
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;
using System.IO;
using System;

public class EEGMarker
{
    TcpClient tcpClient;
    NetworkStream stream;
    byte[] triggerID;


    public EEGMarker()
    {
        tcpClient = new TcpClient(); //(ip, portID);

    }

    //Connect to the network (data acquisition server)
    public void Connect(string ip, int portID)
    {
         try
        {
            tcpClient.Connect(ip, portID);

        }
        catch (SocketException e)
        {

            Debug.Log(e.Message);

        }

        //initialize
        if (tcpClient != null && tcpClient.Connected)
        {
            stream = tcpClient.GetStream();           
        }

        triggerID = new byte[24];
    }

    public bool isConnected()
    {
        if (tcpClient != null && tcpClient.Connected)
            return true;
        else return false;
    }

    public void Disconnect()
    {
        tcpClient.Close();
        stream.Close();
        Debug.Log("tcpClient Disconnected");
    }

    
    ///send the marker
    public void SendTrigger(byte trigger)
    {
        if (tcpClient == null)
        {
            Debug.Log("null tcpClient ");
            return;
        }
        try
        {		
            if (stream.CanWrite)
            {
                triggerID[8] = trigger;
                stream.Write(triggerID, 0, triggerID.Length);
                //for (int i = 0; i < 24; i++)
               //     if (triggerID[i] != (byte)0)
               //         Debug.Log("not zero i=" + i);
            }
        }
        catch (SocketException socketException)
        {
            Debug.Log("Socket exception: " + socketException);
        }

    }


    /*
    // Send stimulation with a timestamp. 
    void send(Long stimulation, Long timestamp) throws Exception
    {
        ByteBuffer b = ByteBuffer.allocate(24);
        b.order(ByteOrder.LITTLE_ENDIAN); // Assumes AS runs on LE architecture
        b.putLong(0);              // Not used
        b.putLong(stimulation);    // Stimulation id
        b.putLong(timestamp);      // Timestamp: 0 = immediate

        m_outputStream.write(b.array());

        return true;
    }
    */
}
